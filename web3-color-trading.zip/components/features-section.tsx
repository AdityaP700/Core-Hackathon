import { Bitcoin, Palette, Shield, Sparkles } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function FeaturesSection() {
  const features = [
    {
      icon: <Palette className="h-10 w-10 text-violet-500" />,
      title: "Color Trading",
      description:
        "Trade unique digital colors as assets on our secure blockchain platform. Each color has its own rarity and value.",
    },
    {
      icon: <Bitcoin className="h-10 w-10 text-amber-500" />,
      title: "BTC Integration",
      description: "Seamlessly trade colors using Bitcoin with low transaction fees and fast confirmation times.",
    },
    {
      icon: <Sparkles className="h-10 w-10 text-indigo-500" />,
      title: "AI Analytics",
      description: "Get personalized recommendations and insights powered by our advanced AI algorithms.",
    },
    {
      icon: <Shield className="h-10 w-10 text-green-500" />,
      title: "Secure Platform",
      description: "Your assets are protected with industry-leading security measures and transparent transactions.",
    },
  ]

  return (
    <section id="features" className="py-20 bg-muted/30">
      <div className="container">
        <div className="mx-auto mb-12 max-w-[800px] text-center">
          <h2 className="mb-4 text-3xl font-bold sm:text-4xl md:text-5xl">Platform Features</h2>
          <p className="text-muted-foreground">
            ChromaChain combines the best of Web3 technology with an intuitive user experience
          </p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => (
            <Card key={index} className="border-border/40 bg-background/60 backdrop-blur">
              <CardHeader>
                <div className="mb-2">{feature.icon}</div>
                <CardTitle>{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-20">
          <div className="mx-auto mb-12 max-w-[800px] text-center">
            <h2 className="mb-4 text-3xl font-bold sm:text-4xl">How It Works</h2>
            <p className="text-muted-foreground">Get started with ChromaChain in just a few simple steps</p>
          </div>

          <div className="relative">
            <div className="absolute left-1/2 top-0 h-full w-0.5 -translate-x-1/2 bg-border"></div>
            <div className="grid gap-8">
              {[
                {
                  step: "01",
                  title: "Connect Your Wallet",
                  description: "Securely connect your cryptocurrency wallet to start trading on ChromaChain.",
                },
                {
                  step: "02",
                  title: "Choose Your Colors",
                  description: "Browse the marketplace or create your own unique color assets to trade.",
                },
                {
                  step: "03",
                  title: "Make Transactions",
                  description: "Buy, sell, or trade colors using Bitcoin with real-time market data.",
                },
                {
                  step: "04",
                  title: "Get AI Insights",
                  description: "Receive personalized recommendations and analytics to optimize your trading strategy.",
                },
              ].map((item, index) => (
                <div key={index} className="relative grid gap-6 pl-12 md:grid-cols-5">
                  <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-full border bg-background text-sm font-bold">
                    {item.step}
                  </div>
                  <div className="md:col-span-1">
                    <h3 className="text-xl font-bold">{item.title}</h3>
                  </div>
                  <div className="md:col-span-4">
                    <p className="text-muted-foreground">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

